/* ================================================================
   TabFlow — appearance
   Translates the settings object into CSS custom properties and a
   small set of body/main classes. One entry point (applyAppearance)
   keeps every knob in sync — no per-setting applier drift.
   ================================================================ */

import { q } from '../../common/util.js';
import { THEMES, fontStackFor } from '../../common/themes.js';
import { settings } from '../store.js';
import { registerRenderer } from './bus.js';
import { applyDesign, initDesign } from './design.js';

const FONT_SIZES = { small: '12px', normal: '13px', large: '14px' };
const BG_STYLES = ['gradient-diag', 'gradient-radial', 'gradient-sunset'];
const BG_PATTERNS = ['dots', 'grid', 'noise'];
const DENSITIES = ['comfortable', 'cozy', 'compact'];

export function themeVars(themeId, customThemes) {
  if (/^custom_\d+$/.test(themeId)) {
    const custom = customThemes?.[Number(themeId.split('_')[1])];
    if (custom?.vars) return { ...THEMES.dark.vars, ...custom.vars };
  }
  return (THEMES[themeId] ?? THEMES.dark).vars;
}

/** Whether a theme's background is light (for prefers-color-scheme aware UI). */
export function applyThemeVars(vars) {
  const root = document.documentElement;
  for (const [key, value] of Object.entries(vars)) root.style.setProperty(key, value);
}

function applyAccent(hex) {
  const root = document.documentElement;
  root.style.setProperty('--accent', hex);
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  if (![r, g, b].some(Number.isNaN)) root.style.setProperty('--accent-rgb', `${r},${g},${b}`);
  const channels = [r, g, b].map(c => { c /= 255; return c <= .04045 ? c / 12.92 : ((c + .055) / 1.055) ** 2.4; });
  const light = channels[0] * .2126 + channels[1] * .7152 + channels[2] * .0722;
  root.style.setProperty('--on-accent', light > .179 ? '#111827' : '#ffffff');
}

/** Relative luminance of a #rrggbb color (WCAG); used to detect light themes. */
function isLightColor(hex) {
  if (typeof hex !== 'string') return false;
  const m = hex.replace('#', '');
  if (m.length < 6) return false;
  const chan = (i) => {
    const c = parseInt(m.slice(i, i + 2), 16) / 255;
    return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
  };
  const L = 0.2126 * chan(0) + 0.7152 * chan(2) + 0.0722 * chan(4);
  return L > 0.5;
}

export function applyAppearance() {
  const s = settings();
  const root = document.documentElement;
  const main = q('#main-content');

  const vars = themeVars(s.theme, s.customThemes);
  applyThemeVars(vars);
  applyAccent(s.accent);

  // Light themes need the glass/tonal treatments inverted (dark edges,
  // no white lift on text) — feature CSS keys off this class.
  document.body.classList.toggle('theme-light', isLightColor(vars['--bg'] || vars['--main-bg']));

  root.style.setProperty('--font', fontStackFor(s.font));
  root.style.setProperty('--font-size-base', FONT_SIZES[s.fontSize] ?? FONT_SIZES.normal);
  root.style.setProperty('--radius', `${s.borderRadius}px`);
  root.style.setProperty('--sidebar-w', `${s.sidebarWidth}px`);

  for (const density of DENSITIES) {
    document.body.classList.toggle(`density-${density}`, s.density === density);
  }

  // Background style + pattern live on #main-content.
  for (const style of BG_STYLES) {
    main.classList.toggle(`bg-style-${style}`, s.bgStyle === style);
  }
  main.style.backgroundColor = s.bgStyle === 'custom' && s.customBgColor ? s.customBgColor : '';
  for (const pattern of BG_PATTERNS) {
    main.classList.toggle(`bg-${pattern}`, s.bgPattern === pattern);
  }

  // Advanced visual toggles (see Settings → Advanced).
  document.body.classList.toggle('fx-glass', !!s.glass);
  document.body.classList.toggle('fx-liquid', !!s.liquidGlass);
  root.style.setProperty('--lg-alpha', `${s.lgOpacity}%`);
  root.style.setProperty('--lg-blur', `${s.lgBlur}px`);
  root.style.setProperty('--lg-spec', String(s.lgSpecular / 100));
  root.style.setProperty('--lg-depth', String(s.lgDepth / 100));
  document.body.classList.toggle('fx-lg-glow', !!s.liquidGlass && !!s.lgGlow);
  document.body.classList.toggle('fx-lg-unified', !!s.liquidGlass && !!s.lgUnified);

  // Material You (Pixel) design language — mutually exclusive with liquid.
  document.body.classList.toggle('m3', !!s.materialYou);
  document.body.classList.toggle('m3-motion', !!s.materialYou && !!s.myMotion && !s.reduceMotion);
  document.body.classList.toggle('m3-bold', !!s.materialYou && !!s.myBold);
  root.style.setProperty('--m3-tint', String(s.myTint / 100));
  root.style.setProperty('--m3-radius', `${s.myRadius}px`);
  document.body.classList.toggle('fx-animated-bg', !!s.animatedBg);
  document.body.classList.toggle('fx-reduce-motion', !!s.reduceMotion);
  document.body.classList.toggle('zen', !!s.zenMode);

  applyDesign();
  applyCustomCss(s.customCss);
}

export function applyCustomCss(css) {
  let styleEl = document.getElementById('custom-css');
  if (!styleEl) {
    styleEl = document.createElement('style');
    styleEl.id = 'custom-css';
    document.head.append(styleEl);
  }
  styleEl.textContent = css || '';
}

export function initAppearance() {
  initDesign();
  registerRenderer('appearance', applyAppearance);
}
